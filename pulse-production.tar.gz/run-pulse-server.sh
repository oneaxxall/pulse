#!/usr/bin/env bash
node --no-deprecation pulse-server-js start
